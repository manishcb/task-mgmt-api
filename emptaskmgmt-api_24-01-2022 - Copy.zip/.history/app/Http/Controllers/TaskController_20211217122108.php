<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use App\Models\Taskmaster; // import model


class TaskController extends Controller
{
    //
    
}
