<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CarRegistrationController extends Controller
{
    //
}
