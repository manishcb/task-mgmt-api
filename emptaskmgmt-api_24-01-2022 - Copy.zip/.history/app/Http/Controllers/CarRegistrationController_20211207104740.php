<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use App\Models\Car_registration; // import model

class CarRegistrationController extends Controller
{
    //
    
}
